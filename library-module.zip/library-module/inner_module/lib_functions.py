def lib_func_one():
    print('This is lib function one updated')
